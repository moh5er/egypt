# 🇪🇬 Egypt Travel Shield & Sentiment Hub

> **Empowering international travelers with data-driven safety sentiment, verified YouTube vlogger field notes, real-time Google Maps integration, scam-defense drills, and an audio street phrasebook.**

[![Live Demo](https://img.shields.io/badge/Demo-Live%20Preview-brightgreen)](#-live-deployment--github-pages)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Pure Vanilla JS](https://img.shields.io/badge/Stack-HTML5%20%7C%20CSS3%20%7C%20Vanilla%20JS-blue)](#-tech-stack)

---

## 🌟 Overview

Egypt offers unmatched archaeological and natural wonders, but first-time international visitors often face aggressive touts, pricing ambiguity, and differing safety landscapes. 

**Egypt Travel Shield** bridges the gap between fear and reality. It synthesizes hundreds of real international travel vlogger reports into an objective, interactive web application that differentiates harmless nuisances from legitimate security concerns.

---

## 🚀 Key Features

### 1. 📍 80-Destination Safety & Sentiment Catalog
- Instant search across **80 hand-curated destinations** covering Cairo, Giza, Luxor, Aswan, Red Sea (Hurghada, El Gouna, Marsa Alam), Sinai (Dahab, Sharm El Sheikh, Nuweiba), Alexandria, Western Desert Oases (Siwa, Bahariya, Dakhla), and the Nile Delta.
- Bilingual English & Arabic titles (`name_en` / `name_ar`).
- Nuanced safety levels (e.g. *Very High*, *Safe with Caution*, *High Hassle / Touts*, *Escort Advised*).
- Hassle & Tout Intensity ratings (1 to 5 stars).
- Direct links to international travel vloggers reviewing the exact location on YouTube.

### 2. 🗺️ Live Centering Google Maps Integration
- Embedded dynamic interactive map.
- Automatically recenters on any destination card clicked.
- Quick navigation shortcuts:
  - 🚗 **Directions**: Instant turn-by-turn route to the site.
  - 👮 **Tourist Police**: Nearest tourist police department for help.
  - 🏥 **Hospitals**: Nearest emergency healthcare facility.

### 3. 🛡️ Interactive Scam Buster Simulator
- Real-world scenario training:
  - *The "Free" Camel Photo*
  - *The Closed Gate / Temple Diverter*
  - *The Papyrus & Perfume "Gift" Workshop*
  - *The Broken Taxi Meter Ambush*
- Immediate tactical explanations and de-escalation tips.

### 4. 🗣️ Audio Egyptian Arabic Phrasebook
- Uses browser native **Web Speech API** for authentic Arabic text-to-speech.
- Essential assertive phrases:
  - *"La, Shukran"* (No, thank you — spoken firmly)
  - *"Emshy"* (Walk away / Leave)
  - *"Bi-kam da?"* (How much is this?)
  - *"Shaghal el-addad"* (Turn on the meter)
  - *"Fin el-bolis el-siyahi?"* (Where is the tourist police?)

### 5. 💱 Live Currency & Baksheesh (Tipping) Matrix
- Quick USD to Egyptian Pound (EGP) converter.
- Official etiquette guide on standard tipping ranges for luggage porters, bathroom attendants, felucca captains, and restaurant staff.

---

## 👑 Pro Travel Shield ($9.99 Lifetime Pass)

Included within the client is a premium expansion tier for travelers seeking dedicated route protection:
* **Interactive Route Safety Auditor**: Select multiple cities and traveler demographic (Solo Female, Solo Male, Couple, Family) to calculate comprehensive safety scores, tout indices, and mandatory security convoy notes.
* **Egyptian Taxi & Transfer Fair-Price Shield**: Benchmark fair prices (EGP) for airport transfers, intercity journeys, and Uber vs. white taxi guidelines.
* **Offline Field Manual (PDF Exporter)**: Clean, print-styled emergency pocket guide.
* **Built-in Activation System**: Client-side license key unlocking (`EGYPT2026` for instant evaluation).

---

## 💻 Tech Stack & Zero-Dependency Design

- **Architecture**: 100% Client-side Single Page Application (SPA).
- **Core Technologies**: HTML5, Modern CSS (Flexbox, Grid, Glassmorphism, CSS Custom Properties), Vanilla JavaScript (ES6+).
- **External Dependencies**: None. No npm, no node_modules, no build step required.
- **Hosting Compatibility**: Works out-of-the-box on GitHub Pages, Cloudflare Pages, Netlify, Vercel, or any static file server.

---

## 🌐 Live Deployment / GitHub Pages

To launch your own copy live on the web for free using GitHub Pages:

1. Fork or push this repository to GitHub.
2. In your repository, go to **Settings** > **Pages** (in the left sidebar).
3. Under **Build and deployment** > **Source**, select **Deploy from a branch**.
4. Set the branch to `main` (or `master`) and folder to `/ (root)`.
5. Click **Save**.
6. Within ~60 seconds, your site will be live at:
   ```
   https://<your-username>.github.io/<repository-name>/
   ```

---

## 🛠️ Local Development

To run locally on your machine:

```bash
# Clone the repository
git clone https://github.com/<your-username>/<repository-name>.git

# Navigate to the folder
cd <repository-name>

# Open index.html in any modern web browser
# (or serve using any local HTTP server)
# Python:
python -m http.server 8000

# Node.js:
npx serve .
```

---

## 📄 License

Distributed under the MIT License. See `LICENSE` for more information.

---

*Disclaimer: Safety assessments are aggregated from publicly available travel accounts, government advisories, and traveler consensus. Always exercise situational awareness and check official travel advisories before your trip.*
